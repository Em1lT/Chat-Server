package com.example.user.chatapp
/*
Emil Toivainen
1706854
interface is neede to send main activity a message that there is a new message
 */
interface Observer {

    fun receiveMsg(name: String, msg: String, comment: Int)
    fun toast(msg: String)
    fun backToLogin()
}

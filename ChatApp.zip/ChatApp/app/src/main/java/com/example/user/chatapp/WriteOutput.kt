package com.example.user.chatapp

import java.io.BufferedWriter
import java.io.OutputStreamWriter
import java.io.PrintWriter

/*
Emil Toivainen
1706854
This class is used to write the messages to the server.
 */
class WriteOutput: Thread(){


    fun Write(msg: Users){
        var printWriter = PrintWriter(BufferedWriter(OutputStreamWriter(ConnectThread.socket.getOutputStream())), true)
        printWriter.println(msg.comment)
    }
    fun writeNewUser(name: String){
        var printWriter = PrintWriter(BufferedWriter(OutputStreamWriter(ConnectThread.socket.getOutputStream())), true)

        printWriter.println(":user ${name}")
    }
}
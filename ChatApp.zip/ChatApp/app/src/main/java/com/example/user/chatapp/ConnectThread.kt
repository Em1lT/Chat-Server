package com.example.user.chatapp

import android.util.Log

import java.net.Socket
/*
Emil Toivainen
1706854
Creates the connection to the socket.
 */
object ConnectThread: Runnable{
    lateinit var socket: Socket
    var connected = false

override fun run(){
    Log.d("server", "ConnectThread}")
    val ip = "192.168.43.9"
    try {
        socket = Socket(ip, 9000)
        connected = true
        Log.d("server", "server running ${socket.localPort}")
    } catch (e: Exception) {
        Log.d("server", "Connection failed")
    }

}
}
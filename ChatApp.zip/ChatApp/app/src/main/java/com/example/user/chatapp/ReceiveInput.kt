package com.example.user.chatapp

import android.util.Log
import java.util.*
/*
Emil Toivainen
1706854
This class receives all the input and decides what to do with them. registers the observers.
 */
class ReceiveInput(): Runnable{

    val observers = mutableSetOf<Main2Activity>()

    override fun run() {
        val sc = Scanner(ConnectThread.socket.getInputStream())
        while(ConnectThread.connected){
            var com = sc.nextLine()
            if(com.equals("")|| com.equals(" ") || com.isEmpty() || com.isNullOrBlank()){

            }
            else if (com.equals("Welcome!, press :help for all of the commands")){
               for (items in observers){
                   items.toast("Welcome!")
               }
            }else if(com.equals("Username already in use")){
                for (items in observers){
                    items.backToLogin()
                }
            }else if(com.contains("Username created ")){
                for (items in observers){
                    items.toast("User Created")
                }
            }else{
                if(com.contains("   ") && com.contains("++")){
                    Log.d("server", "own message")
                    var msg = com.replaceBefore("   ", "")
                    for(items in observers){
                        items.receiveMsg(com.replaceAfter("   ",""),msg.substringBefore("++"),1)
                    }
                }else if (com.contains("   ")){
                    Log.d("server", "other message")
                    for(items in observers){
                        items.receiveMsg(com.replaceAfter("   ", ""),com.replaceBefore("   ", ""), 2)
                    }
                }else{
                    for(items in observers){
                        items.receiveMsg("server",com, 3)
                    }
                }

            }
        }
    }

    fun registerObserver(observer: Main2Activity) {
    observers.add(observer)
    }
    fun deRegisterObserver(observer: Main2Activity){
        observers.remove(observer)
    }

}

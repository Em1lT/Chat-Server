package com.example.user.chatapp
/*
Emil Toivainen
1706854
Is uesd to do a clear message
 */
class Users(var name: String = "", var comment: String = "", var myComment: Int = 0)
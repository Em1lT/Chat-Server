package com.example.user.chatapp

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
/*
Emil Toivainen
1706854
This class is used to make the custom adpaters custom ListView. There is also a little logic on how the message background is displayed
 */
class UserListAdapter(private var activity: Activity, private var items: ArrayList<Users>): BaseAdapter() {

    private class ViewHolder(row: View?) {
        var txtName: TextView? = null
        var txtComment: TextView? = null

        init {
            this.txtName = row?.findViewById(R.id.name)
            this.txtComment = row?.findViewById(R.id.messages)
        }
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view: View?
        val viewHolder: ViewHolder
        var layoutInflater = 0
        //if (convertView == null) {
            val inflater = activity?.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            //This orders what layout the listView is going to get. 1 if the item is coming from the person itself. 2 if it's from someone else and the else if it's coming from server
            when(items[position].myComment){
                1 -> {layoutInflater =  R.layout.row_item
                    Log.d("server","${items[position].myComment.toString()} option 1 ")  }
                2 -> {layoutInflater =  R.layout.row_item_left
                    Log.d("server","${items[position].myComment.toString()} option 2 ")  }
                else -> {layoutInflater =  R.layout.row_item_server
                    Log.d("server","${items[position].myComment.toString()} else")  }
            }
            view = inflater.inflate(layoutInflater, null)
            viewHolder = ViewHolder(view)
            view?.tag = viewHolder
        /*} else {
            view = convertView
            viewHolder = view.tag as ViewHolder
        }*/

        var userMsg = items[position]
        viewHolder.txtName?.text = userMsg.name
        viewHolder.txtComment?.text = userMsg.comment

        return view as View
    }

    override fun getItem(i: Int): Users {
        return items[i]
    }

    override fun getItemId(i: Int): Long {
        return i.toLong()
    }

    override fun getCount(): Int {
        return items.size
    }
}
package com.example.user.chatapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.View
import android.view.animation.TranslateAnimation
import android.widget.*
import com.example.user.chatapp.R.id.*
import kotlinx.android.synthetic.main.activity_main2.*
import java.util.*
import kotlin.concurrent.thread

/*
Emil Toivainen
1706854
Most important class. it ties together all of the classes except the mainactivity. it acts as a chat screen to incoming messages and to sended messages
 */
class Main2Activity : AppCompatActivity(), Observer {

    lateinit var toolbar: Toolbar
    lateinit var adapter: UserListAdapter
    val writer = WriteOutput()
    val receiver = ReceiveInput()
    var result = ArrayList<Users>()

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val listView = findViewById<ListView>(R.id.list)
        Thread { ConnectThread.run() }.start()                   //Connection thread
        adapter = UserListAdapter(this, result)
        listView?.adapter = adapter
        Thread { receiver.run() }.start()                       //Thread that receives data from the server

        receiver.registerObserver(this)
        thread { writer.writeNewUser(intent.getStringExtra("Key")) }

        bottom_navigation.setOnNavigationItemSelectedListener {
            when (it.itemId) {
                users -> {
                    writer.Write(Users("", ":users", 1))
                    users1.visibility = (View.VISIBLE)
                    users1.textSize = (60F)
                    users1.startAnimation(TranslateAnimation(1000f, -1000f, 0f, 0f).apply {
                        duration = 4000
                    })
                }
                chat -> {
                    users1.visibility = (View.INVISIBLE)
                }
            }
            return@setOnNavigationItemSelectedListener true
        }
        button_send.setOnClickListener {

            writer.Write(Users(intent.getStringExtra("Key"), message.text.toString() + "++", 2))
            message.text.clear()
            message.requestFocus()
        }
    }

    override fun receiveMsg(name: String, msg: String, comment: Int) {
        Log.d("server", comment.toString())
        var user = Users(name, msg, comment)
        result.add(user)
        this.runOnUiThread { adapter.notifyDataSetChanged() }
    }

    override fun backToLogin() {
        val intent = Intent(this, MainActivity::class.java).apply {
            putExtra("userName", "Again")
            writer.Write(Users("", ":quit", 1))
        }
        startActivity(intent)
    }

    override fun onBackPressed() {

        val builder = AlertDialog.Builder(this)
        builder.setTitle("quit")
        builder.setMessage("Are you sure you want to quit")
        builder.setPositiveButton("yes") { dialog, which ->
            writer.Write(Users("", ":quit", 1))
            receiver.deRegisterObserver(this)
            System.exit(0)
        }
        builder.setNegativeButton("Cancel") { _, _ ->
            Toast.makeText(applicationContext, "You cancelled the dialog.", Toast.LENGTH_SHORT).show()
        }
        val dialog: AlertDialog = builder.create()
        dialog.show()

    }

    override fun toast(msg: String) {
        this.runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

}
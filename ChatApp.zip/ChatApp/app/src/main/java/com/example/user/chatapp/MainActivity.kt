package com.example.user.chatapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main2.*
/*
Emil Toivainen
1706854
Login screen
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_submit.setOnClickListener {
            val name = user_name.text.toString()
            val intent = Intent(this, Main2Activity::class.java).apply {
                putExtra("Key", name)
            }
            startActivity(intent)
        }
        btn_reset.setOnClickListener{
            user_name.text.clear()
        }
    }

    override fun onResume() {
        if (intent.getStringExtra("userName") != null){
            loginAgain.visibility = (View.VISIBLE)
        }
        super.onResume()
    }

}
